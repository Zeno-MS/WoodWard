# Vancouver Public Schools Staffing Investigation: Evidence Package

This directory contains the source data, documents, and analysis for an investigation into Vancouver Public Schools' spending on private staffing agencies from Fiscal Year 2020-21 through 2024-25.

**Every factual claim in the attached articles can be independently verified from the source documents and data exports in this package.**

## Contents

### 01_Payment_Data/
- **`vendor_payments_all_records.csv`**: The complete, deduplicated set of all 391 payment records for the six primary staffing vendors, extracted directly from the district's published board warrant registers. Includes exact payment date, amount, vendor name, and the original raw line from the PDF (which contains the warrant number).
- **`vendor_summary_by_year.csv`**: A pre-calculated pivot table showing total payments and transaction counts per vendor by fiscal year. 

### 02_Personnel_Data/
- Contains salary tier analysis and position breakdowns extracted from the state S-275 personnel reports, documenting the composition of staff reductions during the district's austerity measures. Note: These exports will be populated manually by the researcher in accordance with analytical workflows.

### 03_Budget_Data/
- **`object7_trend_FY2020_FY2025.csv`**: A summary of Vancouver Public Schools' Object 7 (Purchased Services) spending from OSPI F-195 budget reports. It documents the trajectory of the total Object 7 budget and calculates the staffing vendors' growing share of those actual expenditures (rising from 1.1% in FY20-21 to 28.1% in FY24-25).

### 04_Cost_Model/
- **`internal_vs_vendor_cost_model.csv`**: A mathematical model comparing the fully loaded cost of an internal district employee (including salary, SEBB health benefits, DRS retirement, and payroll taxes) against the hourly bill rates charged by staffing agencies (as established in vendor contracts like Attachment A). This quantifies the "premium" paid per hour of contracted labor.

### 05_Source_Documents/
- **`maxim_master_agreement_and_attachment_a_2021.pdf`**: The master service agreement between VPS and Maxim Healthcare (now Amergis), signed in 2021. Includes Attachment A (the rate sheet).
- **`maxim_legal_agreement_2020.pdf`**: The preceding 2020-21 agreement.
- **`sample_warrant_register_october_2024.pdf` / `apportionment_advance_resolution_oct_2024.pdf`**: Sample primary source PDF documents downloaded from VPS BoardDocs (October 8, 2024 meeting) demonstrating cash flow operations and warrant approvals on the consent agenda.
- *(Note: Please ensure the federal DOJ press release regarding the 2011 Maxim settlement and the OSPI SECC 21-32 decision document are manually added here if not already present).*

### 06_Articles/
- Four complete deductive analytical reports (Articles 1-4) tracing the financial, governance, economic, and classroom impacts of the vendor dependency. These are written as investigative analysis prepared from public records, not finished journalism pieces.

### 07_Right_of_Reply/
- Contains verified PDF records of right-of-reply questions submitted to VPS Communications regarding vendor spending and recruitment, with identifying researcher details redacted to preserve source protection.

---
## Note on Methodology
To ensure maximum accuracy, the payment records in this package have been strictly deduplicated to remove exact matches resulting from overlapping board packet attachments. The sum of the deduplicated records in FY24-25 accurately yields $13.3 million in total vendor payments ($10.97 million specifically to Amergis Healthcare). The 5-year total exceeds $32 million. All vendor figures in the accompanying analytical articles utilize this rigorous, deduplicated baseline.
