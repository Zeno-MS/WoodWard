# Person Dossiers Index

This directory contains reference dossiers for all individuals named in the articles or contacted for right of reply.

- [Brett Blechschmidt](brett_blechschmidt.md)
- [Jeff Fish](jeff_fish.md)
- [Jeff Snell](jeff_snell.md)
- [Christopher Smith](christopher_smith.md)
- [Colin Bailey](colin_bailey.md)
- [Cara Bailey](cara_bailey.md)
- [Josh Taylor](josh_taylor.md)
- [Robert Dyer](robert_dyer.md)
- [Alishia Topper](alishia_topper.md)
- [Dr. Torres-Morales](dr_torres-morales.md)
- [Katie Arkoosh](katie_arkoosh.md)
- [Barbra Laurenzo](barbra_laurenzo.md)
- [Allison Abernathy](allison_abernathy.md)
- [Jacquelyn Meza](jacquelyn_meza.md)
- [Heidi Donahue](heidi_donahue.md)
- [Jennifer Ross](jennifer_ross.md)
- [Sonja Hanchar](sonja_hanchar.md)
- [Chipo Sowards](chipo_sowards.md)
- [Janderson](janderson.md)
- [Gpicklesimer](gpicklesimer.md)