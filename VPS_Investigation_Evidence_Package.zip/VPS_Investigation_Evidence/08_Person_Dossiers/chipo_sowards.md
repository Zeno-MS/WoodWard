# Chipo Sowards

## Role & Affiliation
- Union Representative (WEA / VAESP)

## Database / Public Record Data
No matching S-275 personnel records found in database.

## Relevance to Investigation
- *Requires manual editorial synthesis based on articles/emails.*

## External Links
- [Google Search](https://www.google.com/search?q=%22Chipo+Sowards%22+%22Vancouver+Public+Schools%22)
