# Jeff Snell

## Role & Affiliation
- Former Superintendent, Vancouver Public Schools

## Database / Public Record Data
No matching S-275 personnel records found in database.

## Relevance to Investigation
- *Requires manual editorial synthesis based on articles/emails.*

## External Links
- [Google Search](https://www.google.com/search?q=%22Jeff+Snell%22+%22Vancouver+Public+Schools%22)
