# Right of Reply Emails Index

This directory contains 20 verified email communications sent to Vancouver Public Schools administration, board members, and union representatives seeking right of reply and clarification on staffing vendor spending and recruitment practices.

Identifiers of the researcher have been redacted `[REDACTED]` to preserve source protection. The original sent timestamps and exact text of the inquiries remain unaltered.

| # | Date | Recipient | Subject |
|---|------|-----------|---------|
| 1 | Fri, 27 Feb 2026 00:56:37 | Brett Blechschmidt <brett.blechschmidt@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 2 | Fri, 27 Feb 2026 00:57:08 | Jeff Fish <jeff.fish@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 3 | Fri, 27 Feb 2026 00:57:23 | Katie Arkoosh <katie.arkoosh@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 4 | Fri, 27 Feb 2026 00:57:38 | Barbra Laurenzo <barbra.laurenzo@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 5 | Fri, 27 Feb 2026 00:57:46 | Allison Abernathy <allison.abernathy@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 6 | Fri, 27 Feb 2026 00:57:53 | Jacquelyn Meza <jacquelyn.meza@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 7 | Fri, 27 Feb 2026 00:57:59 | Heidi Donahue <heidi.donahue@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 8 | Fri, 27 Feb 2026 00:58:05 | Jennifer Ross <jennifer.ross@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 9 | Fri, 27 Feb 2026 00:58:10 | Sonja Hanchar <sonja.hanchar@vansd.org> | Reply request. Contract staffing, SPED retention, training, and oversight. |
| 10 | Fri, 27 Feb 2026 21:13:05 | Janderson <janderson@washingtonea.org>,Gpicklesimer <gpicklesimer@washingtonea.org> | Request for union input: what labor was told during Purchased Services budget hearings (response due 5:00 PM PT Fri 3/6/26) |
| 11 | Fri, 27 Feb 2026 21:18:06 | Chipo Sowards <chipo.sowards@vansd.org> | Request for union input: para retention, training, and contractor premiums inside Purchased Services (response due 5:00 PM PT Fri 3/6/26) |
| 12 | Fri, 27 Feb 2026 21:22:33 | Vpsboard Directors <vpsboard.directors@vansd.org> | Right of reply request: Board visibility on contracted staffing, training, retention, and Object 7 controls (response due 5:00 PM PT Fri 3/6/26) |
| 13 | Fri, 27 Feb 2026 21:26:02 | Commteam <commteam@k12.wa.us> | Request for comment: OSPI oversight of cash-flow advances, SPED compliance risk, and vendor dependency (response due 5:00 PM PT Fri 3/6/26) |
| 14 | Fri, 27 Feb 2026 21:28:28 | Webmaster <webmaster@sao.wa.gov> | Request for comment: audit scope for staffing vendors, Purchased Services controls, and cash-flow tools (response due 5:00 PM PT Fri 3/6/26) |
| 15 | Fri, 27 Feb 2026 21:38:13 | Alishia Topper <alishia.topper@clark.wa.gov> | Request for comment: Treasurer interactions with VPS leadership (including Brett Blechschmidt) on cash-flow interventions (response due 5:00 PM PT Fri 3/6/26) |
| 16 | Fri, 27 Feb 2026 21:38:13 | Alishia Topper <alishia.topper@clark.wa.gov> | Request for comment: Treasurer interactions with VPS leadership (including Brett Blechschmidt) on cash-flow interventions (response due 5:00 PM PT Fri 3/6/26) |
| 17 | Fri, 27 Feb 2026 22:29:43 | Brett Blechschmidt <brett.blechschmidt@vansd.org> | Follow up Response Requested |
| 18 | Fri, 27 Feb 2026 22:31:31 | Jeff Fish <jeff.fish@vansd.org> | Follow-up Response Requested |
| 19 | Fri, 27 Feb 2026 23:14:57 | "tubthumping@tutamail.com" <tubthumping@tutamail.com> | RE: Request for comment: Treasurer interactions with VPS leadership  (including Brett Blechschmidt) on cash-flow interventions (response due 5:00  PM PT Fri 3/6/26) |
| 20 | Sat, 28 Feb 2026 01:05:26 | Cnty Treasurer General Delivery <treasoff@clark.wa.gov> | RE: Request for comment: Treasurer interactions with VPS leadership  (including Brett Blechschmidt) on cash-flow interventions (response due 5:00  PM PT Fri 3/6/26) |
